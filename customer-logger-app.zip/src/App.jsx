import CustomerLoggerApp from './CustomerLoggerApp';

function App() {
  return <CustomerLoggerApp />;
}

export default App;
